import type { Metadata } from 'next'
import { Inter, Playfair_Display } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-inter',
  display: 'swap',
})

const playfair = Playfair_Display({ 
  subsets: ["latin"],
  variable: '--font-playfair',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Bernabei Automobili | Auto Premium e Sportive Selezionate a Roma',
  description: 'Concessionaria di auto usate premium e sportive a Roma. Selezione accurata, trasparenza garantita e assistenza personalizzata. Scopri le vetture disponibili.',
  keywords: 'auto usate di lusso Roma, auto sportive usate Roma, Porsche usate Roma, concessionaria auto premium Roma, vendita auto sportive Roma',
  generator: 'v0.app',
  openGraph: {
    title: 'Bernabei Automobili | Auto Premium e Sportive Selezionate',
    description: 'Concessionaria di auto usate premium e sportive a Roma. Selezione accurata, trasparenza garantita.',
    type: 'website',
    locale: 'it_IT',
  },
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="it" className={`${inter.variable} ${playfair.variable} bg-background`}>
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
