import { Metadata } from "next"
import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { ArrowRight, Award, Users, Shield, Heart } from "lucide-react"

export const metadata: Metadata = {
  title: "Chi Siamo | Bernabei Automobili",
  description: "Scopri la storia di Bernabei Automobili, la nostra filosofia e l'approccio consulenziale che ci contraddistingue nella vendita di auto premium a Roma.",
}

const values = [
  {
    icon: Shield,
    title: "Trasparenza",
    description: "Ogni vettura viene presentata con la massima onestà. Nessuna sorpresa, nessun difetto nascosto.",
  },
  {
    icon: Award,
    title: "Qualità",
    description: "Selezioniamo solo vetture che soddisfano i nostri rigorosi standard di qualità e affidabilità.",
  },
  {
    icon: Heart,
    title: "Passione",
    description: "L'amore per le automobili guida ogni nostra scelta. Non è solo lavoro, è una passione.",
  },
  {
    icon: Users,
    title: "Relazione",
    description: "Costruiamo rapporti di fiducia che durano nel tempo. Ogni cliente diventa parte della famiglia.",
  },
]

export default function ChiSiamoPage() {
  return (
    <>
      <Header />
      <main className="pt-20">
        {/* Hero */}
        <section className="relative py-24 lg:py-32 bg-primary text-primary-foreground">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="max-w-3xl">
              <span className="text-sm font-medium tracking-widest uppercase text-accent">
                Chi Siamo
              </span>
              <h1 className="mt-4 font-serif text-4xl sm:text-5xl lg:text-6xl font-medium tracking-tight">
                Una passione che diventa professione
              </h1>
              <p className="mt-6 text-xl text-primary-foreground/80 leading-relaxed">
                Da oltre 25 anni accompagniamo i nostri clienti nella scelta della vettura perfetta, con competenza, trasparenza e dedizione.
              </p>
            </div>
          </div>
        </section>

        {/* Story Section */}
        <section className="py-24 bg-background">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <span className="text-sm font-medium tracking-widest uppercase text-accent">
                  La nostra storia
                </span>
                <h2 className="mt-4 font-serif text-3xl sm:text-4xl font-medium text-foreground tracking-tight">
                  Tutto è iniziato con una passione
                </h2>
                <div className="mt-8 space-y-6 text-muted-foreground leading-relaxed">
                  <p>
                    Bernabei Automobili nasce dalla passione di una famiglia per il mondo automotive. Quello che è iniziato come un hobby si è trasformato in una missione: offrire ai nostri clienti un&apos;esperienza di acquisto completamente diversa.
                  </p>
                  <p>
                    Nel corso degli anni, abbiamo costruito una reputazione basata su un unico principio: trattare ogni cliente come vorremmo essere trattati noi. Niente pressioni commerciali, niente mezze verità, solo onestà e competenza.
                  </p>
                  <p>
                    Oggi, con oltre 500 clienti soddisfatti e un tasso di recensioni positive del 97% su AutoScout24, possiamo dire con orgoglio che la nostra filosofia funziona. Ma non ci fermiamo qui: continuiamo ogni giorno a migliorare per offrirvi il meglio.
                  </p>
                </div>
              </div>
              <div className="relative">
                <div className="aspect-[4/5] rounded-sm overflow-hidden">
                  <Image
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1974&auto=format&fit=crop"
                    alt="Brando Bernabei"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="absolute -bottom-6 -left-6 bg-accent px-8 py-6 rounded-sm">
                  <div className="text-3xl font-serif font-semibold text-accent-foreground">25+</div>
                  <div className="text-sm text-accent-foreground/80">Anni di esperienza</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-24 bg-secondary">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <span className="text-sm font-medium tracking-widest uppercase text-accent">
                I nostri valori
              </span>
              <h2 className="mt-4 font-serif text-3xl sm:text-4xl font-medium text-foreground tracking-tight">
                Perché scegliere Bernabei Automobili
              </h2>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value, index) => (
                <div
                  key={index}
                  className="p-8 bg-card rounded-sm border border-border hover:border-accent/50 transition-colors"
                >
                  <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center mb-6">
                    <value.icon className="h-6 w-6 text-accent" />
                  </div>
                  <h3 className="font-semibold text-lg text-foreground mb-3">
                    {value.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {value.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Philosophy Section */}
        <section className="py-24 bg-background">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="max-w-3xl mx-auto text-center">
              <span className="text-sm font-medium tracking-widest uppercase text-accent">
                La nostra filosofia
              </span>
              <h2 className="mt-4 font-serif text-3xl sm:text-4xl font-medium text-foreground tracking-tight">
                Non vendiamo auto. Costruiamo relazioni.
              </h2>
              <blockquote className="mt-8 text-xl text-muted-foreground leading-relaxed italic">
                &ldquo;Quando un cliente entra nel nostro showroom, non vedo una vendita. Vedo una persona che sta per fare un investimento importante e merita tutta la mia attenzione e onestà. È così che ho sempre lavorato, ed è così che continuerò a fare.&rdquo;
              </blockquote>
              <p className="mt-6 font-semibold text-foreground">
                — Brando Bernabei
              </p>
              <div className="mt-12">
                <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  <Link href="/contatti">
                    Prenota un appuntamento
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
