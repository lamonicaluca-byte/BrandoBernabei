"use client"

import { Metadata } from "next"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Phone, Mail, MapPin, Clock, MessageCircle, Send } from "lucide-react"
import { useState } from "react"

const contactInfo = [
  {
    icon: Phone,
    title: "Telefono",
    value: "+39 333 123 4567",
    href: "tel:+393331234567",
    description: "Lun-Sab: 9:00-19:00",
  },
  {
    icon: MessageCircle,
    title: "WhatsApp",
    value: "+39 333 123 4567",
    href: "https://wa.me/393331234567",
    description: "Risposta rapida",
  },
  {
    icon: Mail,
    title: "Email",
    value: "info@bernabeiautomobili.it",
    href: "mailto:info@bernabeiautomobili.it",
    description: "Risposta entro 24h",
  },
  {
    icon: MapPin,
    title: "Indirizzo",
    value: "Via Roma 123, 00100 Roma",
    href: "https://maps.google.com/?q=Via+Roma+123+Roma",
    description: "Visite su appuntamento",
  },
]

export default function ContattiPage() {
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    telefono: "",
    messaggio: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1000))
    
    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  return (
    <>
      <Header />
      <main className="pt-20">
        {/* Hero */}
        <section className="py-16 lg:py-24 bg-primary text-primary-foreground">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="max-w-3xl">
              <span className="text-sm font-medium tracking-widest uppercase text-accent">
                Contatti
              </span>
              <h1 className="mt-4 font-serif text-4xl sm:text-5xl lg:text-6xl font-medium tracking-tight">
                Parliamo della tua prossima auto
              </h1>
              <p className="mt-6 text-xl text-primary-foreground/80 leading-relaxed">
                Sono a tua disposizione per qualsiasi domanda. Contattami senza impegno, sarò felice di aiutarti.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16 bg-background">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16">
              {/* Contact Info */}
              <div>
                <h2 className="font-serif text-2xl font-medium text-foreground mb-8">
                  Come contattarmi
                </h2>
                <div className="grid sm:grid-cols-2 gap-6">
                  {contactInfo.map((item, index) => (
                    <a
                      key={index}
                      href={item.href}
                      target={item.href.startsWith("http") ? "_blank" : undefined}
                      rel={item.href.startsWith("http") ? "noopener noreferrer" : undefined}
                      className="p-6 bg-card rounded-sm border border-border hover:border-accent/50 transition-colors group"
                    >
                      <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                        <item.icon className="h-6 w-6 text-accent" />
                      </div>
                      <h3 className="font-semibold text-foreground mb-1">
                        {item.title}
                      </h3>
                      <p className="text-foreground group-hover:text-accent transition-colors">
                        {item.value}
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">
                        {item.description}
                      </p>
                    </a>
                  ))}
                </div>

                {/* Hours */}
                <div className="mt-8 p-6 bg-secondary rounded-sm">
                  <div className="flex items-center gap-3 mb-4">
                    <Clock className="h-5 w-5 text-accent" />
                    <h3 className="font-semibold text-foreground">Orari di apertura</h3>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Lunedì - Venerdì</span>
                      <span className="text-foreground">9:00 - 19:00</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Sabato</span>
                      <span className="text-foreground">9:00 - 13:00</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Domenica</span>
                      <span className="text-foreground">Chiuso</span>
                    </div>
                  </div>
                  <p className="mt-4 text-xs text-muted-foreground">
                    * Visite su appuntamento anche fuori orario
                  </p>
                </div>
              </div>

              {/* Contact Form */}
              <div>
                <h2 className="font-serif text-2xl font-medium text-foreground mb-8">
                  Inviami un messaggio
                </h2>
                
                {isSubmitted ? (
                  <div className="p-8 bg-green-50 border border-green-200 rounded-sm text-center">
                    <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                      <Send className="h-8 w-8 text-green-600" />
                    </div>
                    <h3 className="text-xl font-semibold text-green-800 mb-2">
                      Messaggio inviato!
                    </h3>
                    <p className="text-green-700">
                      Grazie per avermi contattato. Ti risponderò il prima possibile.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid sm:grid-cols-2 gap-6">
                      <div>
                        <label htmlFor="nome" className="block text-sm font-medium text-foreground mb-2">
                          Nome e Cognome *
                        </label>
                        <Input
                          id="nome"
                          type="text"
                          required
                          value={formData.nome}
                          onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                          className="bg-card border-border focus:border-accent"
                          placeholder="Mario Rossi"
                        />
                      </div>
                      <div>
                        <label htmlFor="telefono" className="block text-sm font-medium text-foreground mb-2">
                          Telefono *
                        </label>
                        <Input
                          id="telefono"
                          type="tel"
                          required
                          value={formData.telefono}
                          onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                          className="bg-card border-border focus:border-accent"
                          placeholder="+39 333 123 4567"
                        />
                      </div>
                    </div>

                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
                        Email *
                      </label>
                      <Input
                        id="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="bg-card border-border focus:border-accent"
                        placeholder="mario@email.com"
                      />
                    </div>

                    <div>
                      <label htmlFor="messaggio" className="block text-sm font-medium text-foreground mb-2">
                        Messaggio *
                      </label>
                      <Textarea
                        id="messaggio"
                        required
                        rows={5}
                        value={formData.messaggio}
                        onChange={(e) => setFormData({ ...formData, messaggio: e.target.value })}
                        className="bg-card border-border focus:border-accent resize-none"
                        placeholder="Salve, sono interessato a..."
                      />
                    </div>

                    <div className="text-xs text-muted-foreground">
                      * Campi obbligatori. I tuoi dati saranno trattati nel rispetto della privacy.
                    </div>

                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-6"
                    >
                      {isSubmitting ? (
                        "Invio in corso..."
                      ) : (
                        <>
                          Invia messaggio
                          <Send className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Map */}
        <section className="h-96 bg-secondary">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2969.6588523485973!2d12.496365676544836!3d41.90278167124027!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x132f61b6532013ad%3A0x28f1c82e908503c4!2sColosseo!5e0!3m2!1sit!2sit!4v1709123456789!5m2!1sit!2sit"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Bernabei Automobili - Mappa"
          />
        </section>
      </main>
      <Footer />
    </>
  )
}
